const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('api', {
  config: () => ipcRenderer.invoke('config'),
  play: (opciones) => ipcRenderer.invoke('play', opciones),
  cerrarSesion: () => ipcRenderer.invoke('cerrar-sesion'),
  abrirMods: (sel) => ipcRenderer.invoke('abrir-mods', sel),
  iniciarSesionMs: () => ipcRenderer.invoke('iniciar-sesion-ms'),
  guardarCuenta: (datos) => ipcRenderer.invoke('guardar-cuenta', datos),
  skin: (datos) => ipcRenderer.invoke('skin', datos),
  elegirSkin: () => ipcRenderer.invoke('elegir-skin'),
  aplicarSkin: (datos) => ipcRenderer.invoke('aplicar-skin', datos),
  guardarRam: (key, valor) => ipcRenderer.invoke('guardar-ram', { key, valor }),
  cosmeticos: () => ipcRenderer.invoke('cosmeticos'),
  abrirEnlace: (url) => ipcRenderer.invoke('abrir-enlace', url),
  on: (canal, fn) => ipcRenderer.on(canal, (_e, datos) => fn(datos)),
});